class PasswordManager

    def initialize
        @pass = {}
    end 

    def add(service, password)
        if valid?(password)
            @pass[service] = password
        end
    end

    def password_for(service)
        return @pass[service]
    end 

    def services
        return @pass.keys

    end 
end
def valid?(password)
    if password.length >= 8
        return password.include?("!") || password.include?("@") || password.include?("$") || password.include?("%") || password.include?("&")
    else
        return false
    end
end